const DBL = require("dblapi.js");
module.exports  = (client) => {
const dbl = new DBL('eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjMyNjU4NDAwODQyNTIwOTg1NiIsImJvdCI6dHJ1ZSwiaWF0IjoxNTQyODI4MTc0fQ.9zAMkfB-LDdA2cCl2SJiT5orxtvQn8uAOJbiAeW7auY', client);
dbl.postStats(client.guilds.size);
 client.user.setPresence({ game: { name: '-help | -invite' }  })

	function getguild (g) {
    var m = sql.query(`SELECT * FROM guilds WHERE id=${g.id}`)
    if(m.length > 0)
        return true;
    
    return false;
  
  }

  client.logger.log(`[READY] ${client.user.tag}, ready to serve ${client.users.size} users in ${client.guilds.size} servers.`, "ready");

  client.guilds.forEach(g => {
    if(getguild(g)) {

    } else {
      sql.query("INSERT INTO guilds (id, name, modlogs, linktime, linkage, linkactive, autorole, roles, securitybans, admintext, adminchannel) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [g.id, g.name, 0, 0, 0, 0, 0, 0, 0, "none", 0]);
    }
  })
};

