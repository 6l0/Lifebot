if (process.version.slice(1).split(".")[0] < 8) throw new Error("Node 8.0.0 or higher is required. Update Node on your system.");
 Discord = require("discord.js");
const { promisify } = require("util");
const readdir = promisify(require("fs").readdir);
const Enmap = require("enmap");
const EnmapLevel = require("enmap-level");
const textSec = 30;
const voiceSec = 60;
const pointsPer = 1;
fs = require('fs');
 moment = require('moment');
const lastinvites = JSON.parse("{}");
moment.locale('ar');
let textDealy = { };
let likeDealy = { };
let voiceInterval = { };
var links = {};
mutes = JSON.parse(fs.readFileSync('./data/mutes.json','utf8'));
users = JSON.parse(fs.readFileSync('./data/users.json','utf8'));
adblock = JSON.parse(fs.readFileSync('./data/adblock.json','utf8'));
let lastJoin = JSON.parse(fs.readFileSync('./data/lastjoin.json','utf8'));
premiuem = JSON.parse(fs.readFileSync('./data/premiuem.json','utf8'));
let membersText = JSON.parse(fs.readFileSync('./data/text.json','utf8'));
let membersVoice = JSON.parse(fs.readFileSync('./data/voice.json','utf8'));
let jointoday = JSON.parse(fs.readFileSync('./data/jointoday.json','utf8'));
var voiceOnline = JSON.parse(fs.readFileSync('./data/voiceO.json','utf8'));
var voiceOnlineRoom = JSON.parse(fs.readFileSync('./data/voiceOR.json','utf8'));
var voiceOnlineText = JSON.parse(fs.readFileSync('./data/voiceOT.json','utf8'));
var welcomeChat = JSON.parse(fs.readFileSync('./data/welcome.json','utf8'));
var welcomeChatText = JSON.parse(fs.readFileSync('./data/welcomeT.json','utf8'));
const client = new Discord.Client();
const user = new Discord.Client();
user.rest.userAgentManager.userAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36';
client.config = require("./config.js");
client.logger = require("./util/Logger");
require("./modules/functions.js")(client);
client.commands = new Enmap();
client.aliases = new Enmap();
client.settings = new Enmap({provider: new EnmapLevel({name: "settings"})});
process.on('unhandledRejection', console.error);
const { exec } = require('child_process');
var test = {}
var mysql = require('sync-mysql');

sql = new mysql({
	host     : 'localhost',
  user     : 'root',
  password : 'pBGWvw8pRt_U7vv(B3}$>nf%?"q',
  database : 'my_db'
});
 var userst = [];
var object = { };

function update () {
setInterval( function () {
	console.log('true!')
var i;
for (i = 0; i < userst.length; i++) {
var result = sql.query(`SELECT money FROM profile WHERE userid = ${userst[i]}`)
if(!result.length) {
sql.query(`INSERT INTO profile (userid, money, exp, level, rep) VALUES (${userst[i]}, 0, 1, 0, 0)`)
} 
var exp = sql.query(`SELECT exp FROM profile WHERE userid = ${userst[i]}`)
var level = sql.query(`SELECT level FROM profile WHERE userid = ${userst[i]}`)
var money = sql.query(`SELECT money FROM profile WHERE userid = ${userst[i]}`)
const curLevel = Math.floor(0.1 * Math.sqrt(exp[0].exp));
sql.query(`UPDATE profile SET exp = ${exp[0].exp + object[userst[i]].exp} WHERE userid = ${userst[i]}`)
sql.query(`UPDATE profile SET money = ${money[0].money + object[userst[i]].credits} WHERE userid = ${userst[i]}`)
if(level[0].level < curLevel) {
level[0].level = curLevel;
sql.query(`UPDATE profile SET level = ${level[0].level++} WHERE userid = ${userst[i]}`)
} 
object = {};
userst = [];
}
}, 5000) 
}
//update()

function runpremiuembots () {
var result = sql.query(`SELECT * FROM guilds WHERE premium = 1`);
if(!result.length) return;
console.log(result.length)
var i;
for (i = 0; i < result.length; i++) { 
	console.log(`pm2 start premiuem.js --name ${result[i].id} -- ${result[i].token}`)
//exec(`pm2 start premiuem.js --name ${result[i].id} -- ${result[i].token}`)
}
}
function ownersRole (message) {
	var result = sql.query(`SELECT * FROM guilds WHERE premium = 1`);
	if(!result.length) return;
	var i;
for (i = 0; i < result.length; i++) { 
	const rank = message.guild.roles.find('name',"'Premium 💛")
	message.guild.members.get(result[i].owner).addRole(rank.id)
}
}	
function addpremiuembot (message, m, token, botid) {
if(message.author.id !== client.config.ownerID) return;
sql.query(`UPDATE guilds SET premium = 1 WHERE id = ${botid}`)
sql.query(`UPDATE guilds SET owner = ${m.id} WHERE id = ${botid}`)
sql.query(`UPDATE guilds SET token = '${token}' WHERE id = ${botid}`)
exec(`pm2 start premiuem.js --name ${botid} -- ${token}`)
}

function login() {
	var userTokens = ["Mjk2OTIzNTU2MjU0NzExODE5.DPtihg.Vz-_EJMhL1oConhJUYHwmGjvfqg", "Mjk2OTI0MDM1NDcwNzIxMDI2.DPtilw.mn0ceC3OFEYcKoNzY6I6B4vedBk", "Mjk2OTI0MTczMDM5ODI4OTkz.DPtiug.E7smZdwoG0zBm-VWDRq1lOtEtJ4", "Mjk2OTI1MjQ2NTM4MTIxMjE3.DPti1w.O9QM_XSQhvYQkFKyCQzUbVGTcdg"];
	user.login(userTokens[Math.floor(Math.random() * userTokens.length)])
}
function checkPublishers() {
	setInterval (function (){
	if(adblock["two"] == adblock["one"]) {
		adblock["two"] = 0;
	}
		adblock["two"]++;
		fs.writeFileSync('./data/adblock.json',JSON.stringify(adblock));
client.fetchInvite(adblock["code"][adblock["two"]])
  .then(invite => {
user.user.acceptInvite(invite.code)
  .catch(console.error);
})
	leave()

	},1000*60*10);
	
	
	}
	function leave () {
		setTimeout( function( ) {
var guild = user.guilds.get(adblock["guilds"][adblock["two"]]);
if(!guild) {
		adblock["two"]++;
		fs.writeFileSync('./data/adblock.json',JSON.stringify(adblock));
} else {
		user.guilds.get(adblock["guilds"][adblock["two"]]).leave();
		adblock["two"]++;
		fs.writeFileSync('./data/adblock.json',JSON.stringify(adblock));
}
		}, 1000*60)
		}
		
const init = async () => {

  const cmdFiles = await readdir("./commands/");
  client.logger.log(`Loading a total of ${cmdFiles.length} commands.`);
  cmdFiles.forEach(f => {
    if (!f.endsWith(".js")) return;
    const response = client.loadCommand(f);
    if (response) console.log(response);
  });

  const evtFiles = await readdir("./events/");
  client.logger.log(`Loading a total of ${evtFiles.length} events.`);
  evtFiles.forEach(file => {
    const eventName = file.split(".")[0];
    const event = require(`./events/${file}`);
    client.on(eventName, event.bind(null, client));
    const mod = require.cache[require.resolve(`./events/${file}`)];
    delete require.cache[require.resolve(`./events/${file}`)];
    for (let i = 0; i < mod.parent.children.length; i++) {
      if (mod.parent.children[i] === mod) {
        mod.parent.children.splice(i, 1);
        break;
      }
    }
  });

  client.levelCache = {};
  for (let i = 0; i < client.config.permLevels.length; i++) {
    const thisLevel = client.config.permLevels[i];
    client.levelCache[thisLevel.name] = thisLevel.level;
  }

	client.on("ready", () => {
		console.log(`Logged in as ${client.user.tag}!`);
runpremiuembots();
		client.guilds.forEach( ( guild ) => {
			if( welcomeChat[guild.id] ){
				if( guild.me.hasPermission( 'MANAGE_GUILD' ) ) {
					guild.fetchInvites().then((data) => {
						data.forEach((Invite, key, map) => {
							var Inv = Invite.code;
							lastinvites[Inv] = Invite.uses;
						})
					})
				}
			}
		});
	});
	
user.on('message', async message => {
    if(message.channel.type == "dm") {
        if(!/discord\.gg\/\w+|bot\.discord\.io\/\w+|discordapp\.com\/invites\/\w+|discord\.me\/\w+/g.test(message.content)) return
        var channel = client.channels.get(adblock["channels"][adblock["guilds"][adblock["two"]]])
if(!channel) return;
        if(channel) {
			let links = message.content.match(/(https:\/\/)?(www\.)?(discord\.gg|discord\.me|discordapp\.com\/invite|discord\.com\/invite)\/([a-z0-9-.]+)?/i);
			if (links) {
			  let inv = await client.fetchInvite(links[0])
			  let gg = await inv.guild.id
		channel.send(message.author + ' نشر' + inv)
			}

        }

    }
})
	user.on('ready', () => {
		checkPublishers()
		console.log(`Logged in as ${user.user.tag}!`);
	})
	function refreshVoice( ){
			fs.writeFileSync('./data/voiceO.json',JSON.stringify(voiceOnline));
			fs.writeFileSync('./data/voiceOR.json',JSON.stringify(voiceOnlineRoom));
			fs.writeFileSync('./data/voiceOT.json',JSON.stringify(voiceOnlineText));
	}
	
	function refreshOnlineCount( ){
		client.guilds.forEach( ( guild ) => {
if(!guild.me.hasPermission( 'MANAGE_CHANNELS' ) ) return;
			if( voiceOnline[guild.id] ){
				var count = 0;
				guild.channels.filter(c=>c.type=='voice').forEach( ( c ) => {
					count += c.members.size;
				});
				if( guild.channels.get(voiceOnlineRoom[guild.id]) ){
					if( voiceOnlineText[guild.id] == "" ) {
				      if(!guild.channels.get(voiceOnlineRoom[guild.id])) return;
						guild.channels.get(voiceOnlineRoom[guild.id]).edit({name: "عدد اعضاء الفويس: "+count,bitrate:96000});
					} else {
				      if(!guild.channels.get(voiceOnlineRoom[guild.id])) return;
						guild.channels.get(voiceOnlineRoom[guild.id]).edit({name: voiceOnlineText[guild.id].replace("00",count),bitrate:96000});
					}
                                        
				}
			}
		});
		refreshVoice();
	}
	function now( ) {
		var today = new Date();
		var dd = today.getDate();
		var mm = today.getMonth()+1;
		var h = today.getHours();
		var a = today.getHours() < 12 ? 'AM' : 'PM';
		var m = today.getMinutes();
		var yyyy = today.getFullYear();
		var today = yyyy+'/'+mm+'/'+dd+' '+h+':'+m+' '+a;
		return today
	}
	function getDays(first, second) {
		return Math.round((second-first)/(1000*60*60*24));
	}

	function getInvites( member ){
		return new Promise(resolve => {
			var invitecount = 0;
			member.guild.fetchInvites( ).then( ( invites ) => {
				var invitescount = invites.size;
				var i = 0;
				if( invitescount == 0 ){
					resolve(invitecount)
				}
				invites.forEach( ( invite, inviteCode, invites ) => {
					i++;
					if( invite.inviter.id == member.id ){
						invitecount+=invite.uses;
					}
					if( i == invitescount ){
						resolve(invitecount)
					}
				})
			});
		});
		
	}
	JSON.sort = function(o) {
		const isObject = (v) => ('[object Object]' === Object.prototype.toString.call(v));

		if (Array.isArray(o)) {
			return o.sort().map(v => isObject(v) ? JSON.sort(v) : v);
		} else if (isObject(o)) {
			return Object
				.keys(o)
				.sort(function ( a, b ) { return o[b] - o[a] })
				.reduce((a, k) => {
					if (isObject(o[k])) {
						a[k] = JSON.sort(o[k]);
					} else if (Array.isArray(o[k])) {
						a[k] = o[k].map(v => isObject(v) ? JSON.sort(v) : v);
					} else {
						a[k] = o[k];
					}

					return a;
				}, {});
		}

		return o;
	}

	
	client.on("message", ( message ) =>{
		if( !message.guild ) return;
		if( !message.member ) return;
		var msgcontent = sql.query(`SELECT admintext FROM guilds WHERE id = ${message.guild.id}`)[0].admintext;
		if(msgcontent.length)  {
			if(message.content.startsWith(msgcontent[0].admintext)) {
			var channel = client.channels.get(sql.query(`SELECT adminchannel FROM guilds WHERE id = ${message.guild.id}`)[0].adminchannel);
			if(channel) {


if(message.member.voiceChannel) {
	const embed = new Discord.RichEmbed()
	.setColor("RANDOM")
.setAuthor(`${message.author.username}`)         
.addField(' شخص يطلب الادارة ', `هناك شخص يطلب الاداره بشات ${message.channel}`) 
.addField(' متواجد برومات الصوت ', `متواجد بروم ${message.member.voiceChannel.name}`) 
channel.send({embed});		
} else {
	const embed = new Discord.RichEmbed()
	.setColor("RANDOM")
.setAuthor(`${message.author.username}`)         
.addField(' شخص يطلب الادارة ', `هناك شخص يطلب الاداره بشات ${message.channel}`) 
channel.send({embed});		
} 
		}
		}
		}
	
		if(message.content.startsWith('رابط')) {
			if(sql.query(`SELECT linkactive FROM guilds WHERE id = ${message.guild.id}`)[0].linkactive == 1) {
				message.channel.createInvite({maxAge: sql.query(`SELECT linktime FROM guilds WHERE id = ${message.guild.id}`)[0].linktime*60, maxUses: sql.query(`SELECT linkage FROM guilds WHERE id = ${message.guild.id}`)[0].linkage}, "AUTOLINK - LifeBot").then(m => {
				var min = sql.query(`SELECT linktime FROM guilds WHERE id = ${message.guild.id}`)[0].linktime;
					message.author.send(` \n \n  ** Link duration: ${min} min \n Number of uses of the link: ${sql.query(`SELECT linkage FROM guilds WHERE id = ${message.guild.id}`)[0].linkage} \n \n ${m.url}**`)
				links[m.code] = message.author.id;
				})
				message.channel.send('** The link has been sent to your user **')
}
			}
		if(message.content.startsWith('-startroles')) {
			if(message.author.id !== client.config.ownerID) return;
			ownersRole(message)	
		}
        if(message.content.startsWith('-addbot')) {
			if(message.author.id  !== client.config.ownerID) return;
			var args = message.content.split(" ").slice(1);
    let m = message.guild.member(message.mentions.users.first()) || message.guild.members.get(args[0]);
    if(!m) return message.channel.send(":exclamation: ** ألرجاء تحديد الشخص عن طريق المنشن **");
			addpremiuembot(message, m, args[1], args[2])
		}
     if(premiuem["botsid"].includes(message.guild.id)) return;
		if( message.content.startsWith( "-welcome" ) ){
			if( !message.member.hasPermission('ADMINISTRATOR') ) return message.reply(':x: لا يمكنك استخدام الامر');
			var args = message.content.split(" ").slice(1);
			if( args[0] != 'off' && !message.mentions.channels.filter(c=>c.type=='text').first() ) return message.reply(':x: يرجى منشنة الشات المراد الترحيب به');
			var text = message.content.split(" ").slice(2).join( " " );
			if( args[0] != 'off' && text == "" ) return message.reply(':x: يرجى كتابة نص الترحيب\n سيتم استبدال كلاً من \n[server]: الى اسم السيرفر\n[member]: وسيتم استبدال هذا بمنشنة العضو الذي تم ترحيبه');
			if( args[0] != 'off' ){
				welcomeChat[message.guild.id] = message.mentions.channels.filter(c=>c.type=='text').first().id;
				welcomeChatText[message.guild.id] = text;
				message.reply(':white_check_mark: تم تفعيل خاصية الترحيب في شات '+message.mentions.channels.filter(c=>c.type=='text').first());
			} else {
				message.reply(':white_check_mark: تم الغاء خاصية الترحيب ');
				welcomeChat[message.guild.id] = undefined;
			}
			fs.writeFileSync('./data/welcome.json',JSON.stringify(welcomeChat));
			fs.writeFileSync('./data/welcomeT.json',JSON.stringify(welcomeChat));
		}
		if( message.content.startsWith( "-vc" ) ){
			if( !message.member.hasPermission('ADMINISTRATOR') ) return message.reply(':x: لا يمكنك استخدام الامر');
			var args = message.content.split(" ").slice(1);
			if( !args[0] ) return message.reply(':x: يرجى كتابة اياً من ``on`` او ``off``\n``on``: تشير الى تفعيل خاصية حساب عدد اعضاء الفويس\n``f``: تشير الى اطفاء الخاصية');
			var text = message.content.split(" ").slice(2).join( " " );
			if( args[0] != 'off' && text == "" ) return message.reply(':x: يرجى كتابة ``00`` لانها تشير لعدد الاعضاء');
			if( args[0].toLowerCase() == 'on' ){
				if( !voiceOnline[ message.guild.id ] ){
					message.guild.createChannel(text,'voice',[{
  id: message.guild.id,
  deny: ['CONNECT']
}]).then( (c) => {
						voiceOnline[ message.guild.id ] = true
						voiceOnlineRoom[ message.guild.id ] = c.id;
						if( text != "" ){
							voiceOnlineText[ message.guild.id ] = text;
						}
						refreshVoice();
						message.reply(':white_check_mark: تم فتح الخاصية بنجاح');
					} ).catch( ( er ) => {
						console.log(er)
						message.reply(':x: لم استطع انشاء الغرفة بسبب عدم امتلاكي للصلاحيات ')
					} )
				} else {
						message.reply(':x: الخاصية مفتوحة بالفعل');
					
				}
			} else if( args[0].toLowerCase() == 'off' ){
				if( voiceOnline[ message.guild.id ] ){
					message.reply(':white_check_mark: تم اغلاق الخاصية بنجاح');
					voiceOnline[ message.guild.id ] = undefined
					voiceOnlineText[ message.guild.id ] = undefined;
if(!message.member.guild.channels.get(voiceOnlineRoom[ message.guild.id ])) return message.reply('i Cant so much');
					message.member.guild.channels.get(voiceOnlineRoom[ message.guild.id ]).delete();
					voiceOnlineRoom[ message.guild.id ] = undefined;
					refreshVoice();
				} else {
					message.reply(':x: الخاصية مغلقة بالفعل');
				}
			} else {
				message.reply(':x: لم استطع التحديد, يرجى اختيار ``on`` او ``off``');
			}
		}
		
		if( message.content.split(' ')[0] == "-id" ){
			let member = message.member;
			if( message.mentions.members.first( ) ){
				member = message.mentions.members.first( );
			}
console.log(member.joinedTimestamp)
			let embed = new Discord.RichEmbed()
			.setThumbnail(member.user.displayAvatarURL)
			.setFooter('© LifeBot 2016-2018')
			.setColor(0x36393f)
			.setAuthor(member.displayName,member.user.displayAvatarURL)
			.addField('» المستوى الكتابي',Math.round((membersText[ member.id ] || 0)/100),true)
			.addField('» المستوى الصوتي',Math.round((membersVoice[ member.id ] || 0)/100),true)
			.addField('» النقاط الكتابية',(membersText[ member.id ] || 0),true)
			.addField('» النقاط الصوتية',(membersVoice[ member.id ] || 0),true)
			.addField('» مضى على دخولك الديسكورد',"يوماً " + getDays(member.user.createdTimestamp,Date.now()),true)
			.addField('» مضى على دخولك للسيرفر',"يوماً " + getDays(member.joinedTimestamp,Date.now()),true)
			getInvites(member).then( invites => {
				embed.addField('» دعوت',"شخصاً " + invites,true)
				message.reply( { embed } );
			});
			
		}
				
		
});


	client.on("voiceStateUpdate", ( o, n ) =>{
		refreshOnlineCount();
		if( n.voiceChannel ) {
			if( lastJoin[n.guild.id] == undefined ){
				lastJoin[n.guild.id] = { };
			}
			lastJoin[n.guild.id][ n.id ] = now( );
			fs.writeFileSync('./data/lastjoin.json',JSON.stringify(lastJoin));
			if( !voiceInterval[n.guild.id] ){
				voiceInterval[n.guild.id] = { }
			}
			if( voiceInterval[n.guild.id][n.id] ) return;
			if( membersVoice[n.guild.id] == undefined ){
				membersVoice[n.guild.id] = { };
			}
			if( membersVoice[n.guild.id][n.id] == undefined ){
				membersVoice[n.guild.id][n.id] = 0;
			}
			voiceInterval[n.guild.id][n.id] = setInterval( function ( ){
				if( !n.user.bot ){
					if( n.voiceChannel.members.size >= 2 ){
						if( n.mute == false ) {
							membersVoice[n.guild.id][n.id]++;
							fs.writeFileSync('./data/voice.json',JSON.stringify(membersVoice));
						}
					}
				}
			}, voiceSec*1000 )
		} else {
			if( !voiceInterval[n.guild.id] ){
				voiceInterval[n.guild.id] = { }
			}
			if( !voiceInterval[n.guild.id][n.id] ) return;
			clearInterval( voiceInterval[n.guild.id][n.id] );
			voiceInterval[n.guild.id][n.id] = undefined
			
		}
	}) 
	client.on('guildBanAdd', function(guild, user) {
		if(!guild.me.hasPermission( 'MANAGE_GUILD' )) return;
		if(!guild.me.hasPermission( 'VIEW_AUDIT_LOG' )) return;

		guild.fetchAuditLogs().then(logs => {
		  const ser = logs.entries.first().executor;
          if(!actionDaily[guild.id + user.id]) {
			  actionDaily[guild.id + user.id] = {};
			  actionDaily[guild.id + user.id]["ban"] = 0;
			  actionDaily[guild.id + user.id]["ban"]++;
		  }
			  if(actionDaily[guild.id + user.id]["ban"] == sql.query(`SELECT securitybans FROM guilds WHERE id = ${guild.id}`)[0].securitybans) {
				if(!guild.me.hasPermission( 'MANAGE_ROLES' )) return;
			var roles = guild.members.get(ser.id).roles.keyArray();
			guild.members.get(ser.id).removeRoles(roles);			  
		  } else {
			actionDaily[guild.id + user.id]["ban"]++;

		  }
		})
	})
		client.on('guildBanAdd', function(guild, user) {
		if(!guild.me.hasPermission( 'MANAGE_GUILD' )) return;
		if(!guild.me.hasPermission( 'VIEW_AUDIT_LOG' )) return;

		const log = guild.channels.get(sql.query(`SELECT modlogs FROM guilds WHERE id = ${guild.id}`)[0].modlogs);
		guild.fetchAuditLogs().then(logs => {
		  const ser = logs.entries.first().executor;
		  if(guilds[guild.id]["security"]["ban"] !== 0) {
         if(!actionDaily[user.id + guild.id]) {
			 actionDaily[user.id + guild.id] = {};
			 actionDaily[user.id + guild.id]["ban"] = 1;
			 if(guilds[guild.id]["security"]["ban"] == actionDaily[user.id + guild.id]["ban"]) {
				var roles = guild.members.get(ser.id).roles.keyArray();
				console.log(roles)
				guild.members.get(ser.id).removeRoles(roles);
			 }
		 } else {
			if(guilds[guild.id]["security"]["ban"] == actionDaily[user.id + guild.id]["ban"]) {
				var roles = guild.members.get(ser.id).roles.keyArray();
				console.log(roles)
				guild.members.get(ser.id).removeRoles(roles);
			 }
		 actionDaily[user.id + guild.id]["ban"]++;
		 console.log(actionDaily[user.id + guild.id]["ban"])
		 }
		  }
		  const embed = new Discord.RichEmbed()
		.setAuthor(guild.name)
		.setDescription(`**banned : #${user} by ${ser}**`)
		.setColor('#00FF00')
		.setFooter(`ID: ${user.id}`)
		.setTimestamp();
        if (!log) return;
		log.send({embed})
	  })
	  });



    client.on('guildBanRemove', function(guild, user) {
		if(!guild.me.hasPermission( 'MANAGE_GUILD' )) return;
		if(!guild.me.hasPermission( 'VIEW_AUDIT_LOG' )) return;

		const log = client.channels.get(sql.query(`SELECT modlogs FROM guilds WHERE id = ${guild.id}`)[0].modlogs);
		guild.fetchAuditLogs().then(logs => {
		  const ser = logs.entries.first().executor;
		  const embed = new Discord.RichEmbed()
		  .setAuthor(guild.name)
		  .setDescription(`**unbanned : #${user} by ${ser}**`)
		  .setColor('#090999')
		  .setFooter(`ID: ${user.id}`)
		  .setTimestamp();
		  if (!log) return;
		  log.send({embed})
		})
	  });

	  client.on('roleCreate', function(role) {
		if(!role.guild.me.hasPermission( 'MANAGE_GUILD' )) return;
		if(!role.guild.me.hasPermission( 'VIEW_AUDIT_LOG' )) return;

		const log = client.channels.get(sql.query(`SELECT modlogs FROM guilds WHERE id = ${role.guild.id}`)[0].modlogs);
		role.guild.fetchAuditLogs().then(logs => {
		  const ser = logs.entries.first().executor;
		const embed = new Discord.RichEmbed()
		.setAuthor(role.guild.name)
		.setDescription(`**Role create : #${role.name} by ${ser}**`)
		.setColor('#F1F1F1')
		.setFooter(`ID: ${role.id}`)
		.setTimestamp();
		if (!log) return;
		log.send({embed})
	  })
	})
	client.on('roleDelete', function(role) {
		if(!role.guild.me.hasPermission( 'MANAGE_GUILD' )) return;
		if(!role.guild.me.hasPermission( 'VIEW_AUDIT_LOG' )) return;

		const log = client.channels.get(sql.query(`SELECT modlogs FROM guilds WHERE id = ${role.guild.id}`)[0].modlogs);
		role.guild.fetchAuditLogs().then(logs => {
		  const ser = logs.entries.first().executor;
		const embed = new Discord.RichEmbed()
		.setAuthor(role.guild.name)
		.setDescription(`**Role Delete : #${role.name} by ${ser}**`)
		.setColor('#813232')
		.setFooter(`ID: ${role.id}`)
		.setTimestamp();
		if (!log) return;
		log.send({embed})
	  })
	})
	client.on('roleUpdate', function(o,n) {
		if(!o.guild.me.hasPermission( 'MANAGE_GUILD' )) return;
		const log = client.channels.get(sql.query(`SELECT modlogs FROM guilds WHERE id = ${o.guild.id}`)[0].modlogs);
		if(!o.guild.me.hasPermission( 'VIEW_AUDIT_LOG' )) return;

		o.guild.fetchAuditLogs().then(logs => {
		  const ser = logs.entries.first().executor;
		const embed = new Discord.RichEmbed()
		.setAuthor(o.guild.name)
		.setDescription(`**Role Updated : #old name ${o} new name ${n}  by ${ser}**`)
		.setDescription(`**Update role** ${ser}  \n\n**Old**\n\`\`\`js\n${o.name}\`\`\`\n**New** \n\`\`\`js\n${n.name}\`\`\``)
		.setColor('#000000')
		.setFooter(`ID: ${o.id}`)
		.setTimestamp();
		if (!log) return;
		log.send({embed});
	  })
	})

	client.on('channelDelete', function(channel) {
		const log = client.channels.get(sql.query(`SELECT modlogs FROM guilds WHERE id = ${channel.guild.id}`)[0].modlogs);
		if(!channel.guild.me.hasPermission( 'VIEW_AUDIT_LOG' )) return;

		channel.guild.fetchAuditLogs().then(logs => {
			const ser = logs.entries.first().executor;
	  const embed = new Discord.RichEmbed()
	  .setAuthor(channel.guild.name)
	  .setDescription(`**Channel Deleted: #${channel.name} by ${ser}**`)
	  .setColor('#00FF00')
	  .setFooter(`ID: ${channel.id}`)
	  .setTimestamp();
	  if (!log) return;
	  log.send({embed})
	})
	});
client.on('messageUpdate', function(oldMessage, newMessage) {
    if (newMessage.channel.type == 'text' && newMessage.cleanContent != oldMessage.cleanContent) {
		const log = client.channels.get(sql.query(`SELECT modlogs FROM guilds WHERE id = ${newMessage.guild.id}`)[0].modlogs);
        if (!log) return;
         let embed = new Discord.RichEmbed()
            .setDescription(`**Update message** ${newMessage.author} **At** ${oldMessage.channel} \n\n**Old**\n\`\`\`js\n${oldMessage.cleanContent}\`\`\`\n**New** \n\`\`\`js\n${newMessage.cleanContent}\`\`\``)
            .setFooter(oldMessage.author.username, `${oldMessage.author.avatarURL}`)
            .setTimestamp()
            log.send(embed).catch(e => { console.log(e) });
    }
})
	  client.on("guildMemberAdd", ( member ) => {
       if(mutes[member.id]) {
		let voice = member.guild.roles.find(r => r.name === "v-Mute");
		let mutedRole = member.guild.roles.find(r => r.name === "Mute");
		if(!mutedRole)  return;
		if(!voice) return;
		   if(mutes[member.id].reason == "voice") {
      member.addRole(voice)
		   } else {
			   member.addRole(mutedRole)
		   }
	   }
		if( !jointoday[ member.guild.id ] ){
			jointoday[ member.guild.id ] = {};
			jointoday[ member.guild.id ][moment().format("YYYY-MM-DD")] = 0;
		}
		if(!jointoday[ member.guild.id ][moment().format("YYYY-MM-DD")]) {
						jointoday[ member.guild.id ][moment().format("YYYY-MM-DD")] = 0;
		}
		jointoday[ member.guild.id ][moment().format("YYYY-MM-DD")]++;
		if( welcomeChat[ member.guild.id ] ) {
			let text;
			if( welcomeChatText[member.guild.id] != undefined && welcomeChatText[member.guild.id] != "" ){
				text = welcomeChatText[member.guild.id].replace('[member]', member).replace('[server]', '``'+member.guild.name+'``');
			}
			let embed = new Discord.RichEmbed()
			.setThumbnail(member.user.displayAvatarURL)
			.setFooter('© LifeBot 2016-2018')
			.setColor(0x36393f)
			.setAuthor(member.displayName,member.user.displayAvatarURL)
			
			.addField('» مضى على دخولك الديسكورد',getDays(member.user.createdTimestamp,Date.now()) + " يوماً",true)
			.addField('» مضى على دخولك للسيرفر',getDays(member.joinedTimestamp,Date.now()) + " يوماً",true)
			.addField('» رقمك في الدخول اليومي',jointoday[ member.guild.id ][moment().format("YYYY-MM-DD")],true)
			if( text != "" ){
				embed.setDescription(text)
			}
			function getInviter() {
				return new Promise(resolve => {
					member.guild.fetchInvites().then((data) => {
						data.forEach((Invite, key, map) => {
							if( Invite.uses != lastinvites[Invite.code] ){
								lastinvites[Invite.code] = Invite.uses;
                               if(Invite.inviter.id == client.user.id) {
								   if(!links[Invite.code]) {
									resolve( member.guild.members.get(member.guild.ownerID) );
								   } else {
									resolve( member.guild.members.get(links[Invite.code]) );
								   }
							   } else {
								resolve( member.guild.members.get(Invite.inviter.id) );
							}
						}
						})
					})
				})
			}
			async function waitInviter ( ) {
				var inviter = await getInviter();
				if(inviter.id == client.user.id) {
				embed.addField('» تم دعوتك بواسطة',inviter,true)
				} else {
            embed.addField('» تم دعوتك بواسطة',inviter,true)

				}
				member.guild.channels.get(welcomeChat[member.guild.id]).send( { embed } );
			}
			waitInviter ( ) 
		}
		fs.writeFileSync('./data/jointoday.json',JSON.stringify(jointoday));

	});



  client.login(client.config.token);

};

init();
