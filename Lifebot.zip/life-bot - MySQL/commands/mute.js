var time = {};
exports.run = async (client, message, args) => { // eslint-disable-line no-unused-vars
    if(message.member.hasPermission("MANAGE_MESSAGES")) {
        let mm = message.guild.member(message.mentions.users.first()) || message.guild.members.get(args[0]);
        let reason = message.content.split(" ").slice(3);
message.reply(reason)
        if(!mm) return message.channel.send("**رجاء حدد شخص بالمنشن **");
        if(mm.id === message.author.id) return message.channel.send("**لايمكنك اعطاء نفسك ميوت**");
        if(mm.highestRole.position >= message.member.highestRole.position) return message.channel.send("لايمكنك اعطائه ميوت لانه اعلى منك او نفسك!");
        let role = message.guild.roles.find(r => r.name === "Mute");
		if(!role) {
			try {
				role = await message.guild.createRole({
					name: "Mute",
					color: "#FF1111",
					permissions: []
				});
				message.guild.channels.forEach(async (channel, id) => {
					await channel.overwritePermissions(role, {
						SEND_MESSAGES: false,
					});
				});
			} catch(e) {
				return;
			}
		}
        if(mm.roles.has(role.id)) return message.channel.send(":white_check_mark: : **معه ميوت من قبل ! ** ");
         mm.addRole(role);
         if(!args[1]) {
            mutes[mm.id] = {
                guild: message.guild.id,
                time: 0,
                reason: 'text'
              }

         } else {
            if(message.content.endsWith('h')) {

            mutes[mm.id] = {
            guild: message.guild.id,
            time: Date.now() + parseInt(args[1]) * 1000 * 60 * 60,
            reason: 'text'
          }
        }
        if(message.content.endsWith('m')) {

            mutes[mm.id] = {
            guild: message.guild.id,
            time: Date.now() + parseInt(args[1]) * 1000 * 60,
            reason: 'text'
          }
        }
        if(message.content.endsWith('s')) {

            mutes[mm.id] = {
            guild: message.guild.id,
            time: Date.now() + parseInt(args[1]) * 1000,
            reason: 'text'
          }
        }
        if(message.content.endsWith('d')) {
            mutes[mm.id] = {
            guild: message.guild.id,
            time: Date.now() + parseInt(args[1]) * 1000 * 60 * 60 * 24,
            reason: 'text'
          }
        }
        if(message.content.endsWith('y')) {
            mutes[mm.id] = {
            guild: message.guild.id,
            time: Date.now() + parseInt(args[1]) * 1000 * 60 * 60 * 24 * 375,
            reason: 'text'
          }
        }
    }
          fs.writeFile("./data/mutes.json", JSON.stringify(mutes, null, 4), err => {
            if(err) throw err;
          })
         message.channel.send(":crayon: :  ** تم اعطاءه ميوت  بنجاح **");

            var today = moment().format('YYYY');
            var month = moment().format('MM');
            var day = moment().format('DD');
if(args[1]) {
if(args[2]) { 
sql.query(`INSERT INTO usersmute (userid, guildid, date, authorid, reason, time, channel) VALUES (${mm.id} , ${message.guild.id}, '${today}-${month}-${day}', ${message.author.id}, '${reason}' , '${args[1]}', 1)`)

    } else {
        sql.query(`INSERT INTO usersmute (userid, guildid, date, authorid, reason, time, channel) VALUES (${mm.id} , ${message.guild.id}, '${today}-${month}-${day}', ${message.author.id}, 'لايوجد' , '${args[1]}', 1)`)
   
    }
    
} else {
    sql.query(`INSERT INTO usersmute (userid, guildid, date, authorid, reason, time, channel) VALUES (${mm.id} , ${message.guild.id}, '${today}-${month}-${day}', ${message.author.id}, 'لايوجد' , 'مؤبد', 1)`)

}
}
  }  
    exports.conf = {
        enabled: true,
        guildOnly: true,
        aliases: [],
        permLevel: 0
      };
      
      exports.help = {
        name: "mute",
        category: "Miscelaneous",
        description: "It... like... pings. Then Pongs. And it\"s not Ping Pong.",
        usage: "time"
      };
      