const Discord = require('discord.js');

exports.run = async (client, message, args, level) => { // eslint-disable-line no-unused-vars
        message.channel.send("Support server : **https://discord.gg/UhJewNZ**");
		}
exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: "User" // DO NOT LOWER THIS!!!!!!!!
};

exports.help = {
  name: "support",
  category: "System",
  description: "Evaluates arbitrary javascript.",
  usage: "eval [...code]"
};
