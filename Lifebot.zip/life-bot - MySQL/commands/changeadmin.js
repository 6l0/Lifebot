exports.run = async (client, message, args, level) => { // eslint-disable-line no-unused-vars

    if(message.member.hasPermission("ADMINISTRATOR")) {
        if(args[0] == "text") {
            if(!args[1]) return;
        var ann = message.content.replace('-ch text ', '')
        sql.query(`UPDATE guilds SET admintext = "${ann}" WHERE id = ${message.guild.id}`)
        message.reply('تم!').then(m => m.delete())
        }
        if(args[0] == "channel") {
            var channels = message.mentions.channels.first();
if(!channels) return message.reply('يرجى عمل منشن للروم');
sql.query(`UPDATE guilds SET adminchannel = ${channels.id} WHERE id = ${message.guild.id}`)

        
        }
    }
    };
  
  exports.conf = {
    enabled: true,
    guildOnly: true,
    aliases: [],
    permLevel: "User"
  };
  
  exports.help = {
    name: "ch",
    category: "Miscelaneous",
    description: "لدعوه البوت لسيرفرك",
    usage: "invite"
  };
  