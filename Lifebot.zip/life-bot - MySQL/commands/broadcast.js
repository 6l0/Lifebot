const { inspect } = require("util");
var spam = { };
var role_bc = { };
var users = {};
var numbers = {};
var time = {};
var good = {};
var errors = 0;
exports.run = async (client, message, [action, key, ...value], level) => { // eslint-disable-line no-unused-vars
			message.react("ًں’ڑ")
			const args = message.content.split(/\s+/g);

	const settings = client.settings.get(message.guild.id);
	if(client.user.tag == "Life Bot#7820") { 
		if( spam[ message.guild.id ] ) {
		message.reply( ':timer: لاتستطيع حاليا ارسال برودكاست - يرجى الانتظار مابين نصف ساعة حتى 12ساعه - ' )
	} else {
		if(args[1] === "role") return;
    	if(!message.member.hasPermission("ADMINISTRATOR")) return message.channel.sendMessage("*:no_entry: ** عذرآ ليس لديك صلاحيات لارسال برودكاست .. **");
					 var announcement = message.content.replace('-bc ', '').replace('[user]', message.member);
					 	if (args[2]){
        message.reply(`تم ارسال البرودكاست الى ${message.guild.members.filter(m=>m.user.presence.status !== "offline").size} عضو .`)
        message.guild.members.filter(m=>m.user.presence.status !== "offline").forEach(x => x.send(`:loudspeaker: ${message.guild.name} : \n ${announcement}`)).catch(err => errors++)
			spam[ message.guild.id ] = setTimeout( function ( ) {
			spam[ message.guild.id ] = undefined;
		},43200000)
	
						}
	}
  if (args[1] === "role") {
	  				  		const args = message.content.split(/\s+/g);
	  	if( role_bc [ message.guild.id ] ) {
		message.reply( ':timer: لاتستطيع حاليا ارسال برودكاست - يرجى الانتظار مابين 5دقايق حتى ساعه كاملة' )
	} else {
   let member = message.mentions.roles.first();
  if (!member) return message.reply(":negative_squared_cross_mark: ** يرجى عمل منشن / تاق لرتبة حتى يتم عمل برودكاست لها **");
  if(!args[3]) {
						message.reply(":x: ** يرجى كتابة نص **");
		} 
    	if(!message.member.hasPermission("ADMINISTRATOR")) return message.channel.send("*:no_entry: ** عذرآ ليس لديك صلاحيات لارسال برودكاست .. **");
        var announcement = message.content.replace(`-bc role ${args[2]} `, '').replace("[author]", message.author);;
        message.guild.roles.find(r => r.id === member.id).members.map(x => x.send(announcement))
						role_bc [ message.guild.id ] = setTimeout( function ( ) {
			role_bc [ message.guild.id ] = undefined;
		},3600000)
		
				if(!args[3]) {
message.reply(":no_entry: ** عذرأ لم نتاكد من ايجاد الرتبة ** ");
		} 
			message.reply("** تم ارسال الرسالة بنجاح **");
  }
  } 
	} else {
		var bc = message.content.replace(`-bc `, '').replace("[author]", message.author);
		if(!bc) return message.reply('يجب كتابة شي!')
    users[message.guild.id] = [];
    good[message.guild.id] = 0;
    numbers[message.guild.id] = {};
    numbers[message.guild.id]["two"] = 0;
    numbers[message.guild.id]["one"] = 0;
	message.guild.fetchMembers().then(g => {
        g.members.map(m => {
   users[message.guild.id].push(m.id)
   numbers[message.guild.id]["one"]++;
        })
})
message.channel.send('** جاري تنفيذ الأمر .... \n تم تنفيذ الأمر على 0 عضو حتى الأن **').then(m => {
time[message.guild.id] = setInterval (function (){
	if(numbers[message.guild.id]["two"] == numbers[message.guild.id]['one']) {
			clearInterval(time[message.guild.id]);
			m.edit(`** تم تطبيق التغييرات على ${good[message.guild.id]} عضو :clap:**`)
	} else {
	message.guild.members.get(users[message.guild.id][numbers[message.guild.id]['two']]).send(bc).then(yes =>{
			good[message.guild.id]++;
	})
	numbers[message.guild.id]['two']++;
	message.guild.members.get(users[message.guild.id][numbers[message.guild.id]['two']]).send(bc).then(yes =>{
			good[message.guild.id]++;
	})
	numbers[message.guild.id]['two']++;
	message.guild.members.get(users[message.guild.id][numbers[message.guild.id]['two']]).send(bc).then(yes =>{
			good[message.guild.id]++;
	})
	numbers[message.guild.id]['two']++;
	message.guild.members.get(users[message.guild.id][numbers[message.guild.id]['two']]).send(bc).then(yes =>{
			good[message.guild.id]++;
	})
	numbers[message.guild.id]['two']++;
	message.guild.members.get(users[message.guild.id][numbers[message.guild.id]['two']]).send(bc).then(yes =>{
			good[message.guild.id]++;
	})
	numbers[message.guild.id]['two']++;
	
	message.guild.members.get(users[message.guild.id][numbers[message.guild.id]['two']]).send(bc).then(yes =>{
			good[message.guild.id]++;
	})
	numbers[message.guild.id]['two']++;message.guild.members.get(users[message.guild.id][numbers[message.guild.id]['two']]).send(bc).then(yes =>{
			good[message.guild.id]++;
	})
	numbers[message.guild.id]['two']++;
	m.edit(`** جاري تنفيذ الأمر .... \n تم تنفيذ الأمر على ${numbers[message.guild.id]['two']} عضو حتى الأن **`)
	}
	},1000);
	})
}
};
exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: ["broadcast"],
  permLevel: 0
};

exports.help = {
  name: "bc",
  category: "System",
  description: "add / remove the roles.",
  usage: "role"
};