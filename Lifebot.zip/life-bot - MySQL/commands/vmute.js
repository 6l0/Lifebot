var time = {};
exports.run = async (client, message, args) => { // eslint-disable-line no-unused-vars
    if(message.member.hasPermission("MANAGE_MESSAGES")) {
        let reason = message.content.split(" ").slice(3);
        let mm = message.guild.member(message.mentions.users.first()) || message.guild.members.get(args[0]);
        if(!mm) return message.channel.send("**رجاء حدد شخص بالمنشن **");
        if(mm.id === message.author.id) return message.channel.send("**لايمكنك اعطاء نفسك ميوت**");
        if(mm.highestRole.position >= message.member.highestRole.position) return message.channel.send("لايمكنك اعطائه ميوت لانه اعلى منك او نفسك!");
        let role = message.guild.roles.find(r => r.name === "v-Mute");
		if(!role) {
			try {
				role = await message.guild.createRole({
					name: "v-Mute",
					color: "#FF1111",
					permissions: []
				});
				message.guild.channels.forEach(async (channel, id) => {
					await channel.overwritePermissions(role, {
                        SPEAK: false
					});
				});
			} catch(e) {
				return;
			}
		}
        if(mm.roles.has(role.id)) return message.channel.send(":white_check_mark: : **معه ميوت من قبل ! ** ");
         mm.addRole(role);
          
         if(!args[1]) {
            mutes[mm.id] = {
                guild: message.guild.id,
                time: 0,
                reason: 'voice'
              }
         } else {
            if(message.content.endsWith('h')) {
                console.log(' h ' + parseInt(args[1]))

            mutes[mm.id] = {
            guild: message.guild.id,
            time: Date.now() + parseInt(args[1]) * 1000 * 60 * 60,
            reason: 'voice'
          }
        }
        if(message.content.endsWith('m')) {
            console.log(' m ' + parseInt(args[1]))

            mutes[mm.id] = {
            guild: message.guild.id,
            time: Date.now() + parseInt(args[1]) * 1000 * 60,
            reason: 'voice'
          }
        }
        if(message.content.endsWith('s')) {
            console.log(' s ' + parseInt(args[1]))

            mutes[mm.id] = {
            guild: message.guild.id,
            time: Date.now() + parseInt(args[1]) * 1000,
            reason: 'voice'
          }
        }
        if(message.content.endsWith('d')) {
            console.log(' d ' + parseInt(args[1]))
            mutes[mm.id] = {
            guild: message.guild.id,
            time: Date.now() + parseInt(args[1]) * 1000 * 60 * 60 * 24,
            reason: 'voice'
          }
        }
        if(message.content.endsWith('y')) {
            console.log(' y ' + parseInt(args[1]))
            mutes[mm.id] = {
            guild: message.guild.id,
            time: Date.now() + parseInt(args[1]) * 1000 * 60 * 60 * 24 * 375,
            reason: 'voice'
          }
        }
    }
          fs.writeFile("./data/mutes.json", JSON.stringify(mutes, null, 4), err => {
            if(err) throw err;
          })
         message.channel.send(":crayon: :  ** تم اعطاءه ميوت  بنجاح **");

            var today = moment().format('YYYY');
            var month = moment().format('MM');
            var day = moment().format('DD');

            if(args[1]) {
                if(args[2]) { 
                sql.query(`INSERT INTO usersmute (userid, guildid, date, authorid, reason, time, channel) VALUES (${mm.id} , ${message.guild.id}, '${today}-${month}-${day}', ${message.author.id}, '${reason}' , '${args[1]}', 0)`)
                
                    } else {
                        sql.query(`INSERT INTO usersmute (userid, guildid, date, authorid, reason, time, channel) VALUES (${mm.id} , ${message.guild.id}, '${today}-${month}-${day}', ${message.author.id}, 'لايوجد' , '${args[1]}', 0)`)
                   
                    }
                    
                } else {
                    sql.query(`INSERT INTO usersmute (userid, guildid, date, authorid, reason, time, channel) VALUES (${mm.id} , ${message.guild.id}, '${today}-${month}-${day}', ${message.author.id}, 'لايوجد' , 'مؤبد', 0)`)
                
                }
                }
  }  
    exports.conf = {
        enabled: true,
        guildOnly: true,
        aliases: ["vm"],
        permLevel: 0
      };
      
      exports.help = {
        name: "vmute",
        category: "Miscelaneous",
        description: "It... like... pings. Then Pongs. And it\"s not Ping Pong.",
        usage: "time"
      };
      