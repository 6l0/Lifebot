exports.run = async (client, message, args, level) => { // eslint-disable-line no-unused-vars
	if( !message ) return console.log( "An error recorded with 'kick.js' file, I couldn't found the message");
	if( !message.member.hasPermission( 'KICK_MEMBERS' ) ) return message.channel.send( message.member + '**,:x: لا يمكنك استخدام هذا الأمر**' );
	if( message.mentions.members.size < 1 ) return message.channel.send( message.member + '**,:x: ( يرجى منشنة العضو او الاعضاء المراد طردهم ( اقصى عدد هو 10**' );
	let reason = message.content.substring(
		message.content.indexOf('"') + 1, 
		message.content.lastIndexOf('"')
	) || "No reason";
	message.channel.send( message.member + '**:alarm_clock: جاري الطرد, يرجى الانتظار**' ).then ( ( m ) => {
		var members = '';
		message.mentions.members.forEach( ( member, number ) => {
			if( number == 10 ) return;
			var problem = false;
			if( member.id == message.member.id ){
				problem = true;
			}/*
			if( !member.kickable ){
				problem = true;
			}*/
			if( member.permissions > message.member.permissions ){
				problem = true;
				
			}
			member.kick( reason + " by " + message.member.user.tag ).catch( ( err ) =>	{ problem = true; } )
			if( problem == false ){
				members += member;
			}
		});
		if( members == '' ){
			m.edit( message.member + '**,:x: لم أتمكن من الطرد للأسباب المحتملة التالية:** \n**	:black_small_square: ليست لدي الصلاحيات الكافية للطرد **\n**	:black_small_square: الاشخاص او الشخص الذي حددته صلاحياته قوية**\n**	:black_small_square: انك حاولت طرد نفسك**' )
		} else {
			m.edit( message.member + '**,:hammer: بنجاح ' + members + ' تم طرد**' )
		}
	});
  
};

exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: [],
  permLevel: "User"
};

exports.help = {
  name: "kick",
  category: "Admins",
  description: "لطرد الاعضاء",
  usage: "kick @mention @mention"
};
