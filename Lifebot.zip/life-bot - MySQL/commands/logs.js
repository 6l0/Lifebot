exports.run = (client, message) => {
	  if(message.member.hasPermission("MANAGE_GUILD")) {
      const args = message.content.split(/\s+/g);
if(!args[1]) return message.reply('يرجى عمل منشن للروم');
var channels = message.mentions.channels.first();
if(!channels) return message.reply('يرجى عمل منشن للروم');
sql.query(`UPDATE guilds SET modlogs = ${channels.id} WHERE id = ${message.guild.id}`)
message.reply('تم انشاء الوق!')
	  }
}

exports.conf = {
    enabled: true,
    guildOnly: true,
    aliases: [],
    permLevel: "User"
  };
  
  exports.help = {
    name: "logs",
    category: "Miscelaneous",
    description: "It... like... pings. Then Pongs. And it\"s not Ping Pong.",
    usage: "ping"
  };
  