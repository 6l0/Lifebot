 var users = {};
var numbers = {};
var time = {};
var good = {};
var already = [];

exports.run = (client, message) => {
  const args = message.content.split(/\s+/g);

  if(message.member.hasPermission("MANAGE_ROLES")) {
    if(!message.guild.me.hasPermission( 'MANAGE_ROLES')) return message.reply('ليس لدي صلاحيات كافية!');
    if(already.includes(message.guild.id)) return message.reply('جاري العمل بالفعل!');
    if(args[1] == "+") {
      if(!args[2]) return message.reply('يجب ذكر اسم الرول!');
      const rank = message.guild.roles.find('name', args[2])
      if(!rank) return message.reply('لم يتم التعرف على الرول!')
      if(rank.position >= message.member.highestRole.position) return message.channel.send("لايمكن فعل ذلك لان الرول بنفس ترتيبك او اعلى منه!");
      users[message.guild.id] = [];
    good[message.guild.id] = 0;
    numbers[message.guild.id] = {};
    numbers[message.guild.id]["two"] = 0;
    numbers[message.guild.id]["one"] = 0;
	message.guild.fetchMembers().then(g => {
        g.members.map(m => {
   if(m.roles.has(rank.id)) return;
   users[message.guild.id].push(m.id)
   numbers[message.guild.id]["one"]++;
        })
})
message.channel.send('** جاري تنفيذ الأمر .... \n تم تنفيذ الأمر على 0 عضو حتى الأن **').then(m => {
  already.push(message.guild.id)
time[message.guild.id] = setInterval (function (){
if(numbers[message.guild.id]["two"] == numbers[message.guild.id]['one']) {
    clearInterval(time[message.guild.id]);
    var index = already.indexOf(5);
    already.splice(index, 1);
    m.edit(`** تم تطبيق التغييرات على ${good[message.guild.id]} عضو :clap:**`)
} else {
message.guild.members.get(users[message.guild.id][numbers[message.guild.id]['two']]).addRole(rank.id).then(yes =>{
    good[message.guild.id]++;
})
numbers[message.guild.id]['two']++;
m.edit(`** جاري تنفيذ الأمر .... \n تم تنفيذ الأمر على ${numbers[message.guild.id]['two']} عضو حتى الأن **`)
}
},1000);
})
    } 
      if(args[1] == "-") {
        if(!args[2]) return message.reply('يجب ذكر اسم الرول!');
        const rank = message.guild.roles.find('name', args[2])
        if(!rank) return message.reply('لم يتم التعرف على الرول!')
      if(rank.position >= message.member.highestRole.position) return message.channel.send("لايمكن فعل ذلك لان الرول بنفس ترتيبك او اعلى منه!");
      users[message.guild.id] = [];
    good[message.guild.id] = 0;
    numbers[message.guild.id] = {};
    numbers[message.guild.id]["two"] = 0;
    numbers[message.guild.id]["one"] = 0;
	message.guild.fetchMembers().then(g => {
        g.members.map(m => {
          if(m.roles.has(rank.id)) return;
          users[message.guild.id].push(m.id)
   numbers[message.guild.id]["one"]++;
        })
})
message.channel.send('** جاري تنفيذ الأمر .... \n تم تنفيذ الأمر على 0 عضو حتى الأن **').then(m => {
  already.push(message.guild.id);
time[message.guild.id] = setInterval (function (){
if(numbers[message.guild.id]["two"] == numbers[message.guild.id]['one']) {
    clearInterval(time[message.guild.id]);
    var index = already.indexOf(5);
    already.splice(index, 1);
    m.edit(`** تم تطبيق التغييرات على ${good[message.guild.id]} عضو :clap:**`)
} else {
message.guild.members.get(users[message.guild.id][numbers[message.guild.id]['two']]).removeRole(rank.id).then(yes =>{
    good[message.guild.id]++;
})
numbers[message.guild.id]['two']++;
m.edit(`** جاري تنفيذ الأمر .... \n تم تنفيذ الأمر على ${numbers[message.guild.id]['two']} عضو حتى الأن **`)
}
},1000);
})
    }
  }
  
}  
exports.conf = {
      enabled: true,
      guildOnly: true,
      aliases: [],
      permLevel: 0
    };
    
    exports.help = {
      name: "role",
      category: "Miscelaneous",
      description: "It... like... pings. Then Pongs. And it\"s not Ping Pong.",
      usage: "time"
    };
    