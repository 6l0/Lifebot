exports.run = async (client, message, args, level) => { // eslint-disable-line no-unused-vars
if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.reply(`Sorry, you don't have full permission you need`);
    var role = message.mentions.roles.first();
    var member = message.mentions.members.first();
	args[1] = parseInt(args[1]);
    if( !role ) {
        if( !member ){
			args[0] = parseInt(args[0]);
			
            message.channel.bulkDelete(args[0])
			
			setTimeout( function ( ) {
				if( args[0] > 100 ){
					message.channel.bulkDelete(100+args[0]%100)
				}
			}, 1000);
            
        } else {
				
			message.channel.fetchMessages( ).then ( ( messages ) => {
				var i = 0;
				var filteredMessages = messages.filter( ( msg ) => {
					if( i < args[1] && msg.member.id == member.id ){
						i++;
						return msg;
					}
				});
				var filteredMessages1 = messages.filter( ( msg ) => {
					if( i > 100 && i < 100+args[1]%100 && msg.member.id == member.id ){
						i++;
						return msg;
					}
				});
				message.channel.bulkDelete(filteredMessages)
				setTimeout( function ( ) {
					if( parseInt(args[1]) > 100 ){
						message.channel.bulkDelete(filteredMessages1)
					}
				}, 1000);
			} );
			
        }
    } else {
		message.channel.fetchMessages( ).then ( ( messages ) => {
			var i = 0;
			var filteredMessages = messages.filter( ( msg ) => {
				if( i < args[1] && msg.member.roles.get(role.id) ){
					i++;
					return msg;
				}
			});
			var filteredMessages1 = messages.filter( ( msg ) => {
				if( i > 100 && i < args[1] && msg.member.roles.get(role.id) ){
					i++;
					return msg;
				}
			});
			message.channel.bulkDelete(filteredMessages)
			setTimeout( function ( ) {
				if( parseInt(args[1]) > 100 ){
					message.channel.bulkDelete(filteredMessages1)
				}
			}, 1000);
		} );
    };
};

exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: [],
  permLevel: "User"
};

exports.help = {
  name: "clear",
  category: "Miscelaneous",
  description: "It... like... pings. Then Pongs. And it\"s not Ping Pong.",
  usage: "ping"
};
