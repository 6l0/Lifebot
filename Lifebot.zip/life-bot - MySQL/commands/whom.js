exports.run = async(client,message, args) => {
    if(!message.member.hasPermission('MANAGE_MESSAGES')) return;
    let member = message.member;
    if( message.mentions.members.first( ) ){
        member = message.mentions.members.first( );
    }
var result = sql.query(`SELECT * FROM usersmute WHERE guildid = ${message.guild.id} AND userid = ${member.id}`);
if(!result.length) {
    let embed = new Discord.RichEmbed()
    .setColor("000000")
    .setFooter('#' + message.guild.name + ' Mute Automachine')
    .addField("** عدد المرات الي اخذت فيها ميوت **  ", " لم ياخذ اي ميوت من قبل!")
    message.channel.send({embed})
        } else {
var data = {
    'date': [],
    'moderator': [],
    'time': [],
    'reason': [],
    'channels': []
};

let embed = new Discord.RichEmbed()    
.setThumbnail(member.user.displayAvatarURL)
.setFooter('© LifeBot 2016-2018')
        .setColor(0x36393f)
        .setAuthor(member.displayName,member.user.displayAvatarURL)

for (i = 0; i < result.length; i++) {
data['date'].push(result[i].date + ' \n')
data['moderator'].push('<@' + result[i].authorid + '> \n')
data['time'].push(result[i].time + '\n')
data['reason'].push(result[i].reason + ' \n')
if(result[i].channels == 1 ) {
data['channels'].push('روم كتابي \n')
} else {
    data['channels'].push('روم صوتي \n')

}
    } 
    
    embed.addField('» التاريخ ',`**${data['date']}**`,true)
    embed.addField('»  المشرف ',`**${data['moderator']}**`,true)
    embed.addField('»  المدة ',`**${data['time']}**`,true)
    embed.addField('»  السبب ',`**${data['reason']}**`,true)
    embed.addField('»  الروم ',`**${data['channels']}**`,true)
				message.reply( { embed } );
}
/*
if(0 == 1) {
        let embed = new Discord.RichEmbed()
.setColor("000000")
.setFooter('#' + message.guild.name + ' Mute Automachine')
.addField("** عدد المرات الي اخذت فيها ميوت **  ", " لم ياخذ اي ميوت من قبل!")
message.channel.send({embed})
    } else {
var array = [ ];
users[message.guild.id][mm.id].forEach(function(item) {
    array.push(item);
});
let embed = new Discord.RichEmbed()
.setColor("000000")
.setFooter('#' + message.guild.name + ' Mute Automachine')
.addField("** عدد المرات الي اخذت فيها ميوت **  ", "**" + array + "**")
message.channel.send({embed})
}
*/
}
exports.conf = {
    enabled: true,
    guildOnly: true,
    aliases: ["سجل", "see"],
    permLevel: "User" // DO NOT LOWER THIS!!!!!!!!
  };
  
  exports.help = {
    name: "whom",
    category: "System",
    description: "Evaluates arbitrary javascript.",
    usage: "eval [...code]"
  };
  