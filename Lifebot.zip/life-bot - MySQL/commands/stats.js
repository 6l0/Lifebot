const { version } = require("discord.js");
const moment = require("moment");
require("moment-duration-format");
	const Discord = require("discord.js");
  const client = new Discord.Client();
  
  
exports.run = (client, message, args, level) => { // eslint-disable-line no-unused-vars
  const duration = moment.duration(client.uptime).format(" D [days], H [hrs], m [mins], s [secs]");

    const embed = new Discord.RichEmbed()
           .setColor("RANDOM")
           .setDescription("``Stats``")
           .addField('• Uptime' ,`${duration}`)
           .addField('• Users' ,`${client.users.size.toLocaleString()}`)
           .addField('• Servers' ,`${client.guilds.size.toLocaleString()}`)
           .addField('• Channels' ,`${client.channels.size.toLocaleString()}`)
           .addField('• Discord.js' ,`v${version}`)
message.channel.send({embed});

}
exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: "User"
};

exports.help = {
  name: "stats",
  category: "Miscelaneous",
  description: "Gives some useful bot statistics",
  usage: "stats"
};
 // done