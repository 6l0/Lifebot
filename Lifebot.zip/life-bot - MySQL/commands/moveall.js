exports.run = async (client, message, args, level) => { // eslint-disable-line no-unused-vars
    if(!message.member.hasPermission("MANAGE_CHANNELS")) return;
    
        if(message.guild.members.get(message.author.id).voiceChannelID == undefined) return message.reply('يجب ان تكون بالفويس أولا!');
   if(!message.guild.me.hasPermission( 'MANAGE_CHANNELS')) return message.reply('ليس لدي صلاحيات كافية!');
   var count = 0;
                message.guild.channels.filter(c=>c.type=='voice').forEach( ( c ) => {
					count += c.members.size;
				});
if(count <= 1) {
            message.reply(' عذرأ لايوجد غيرك بالفويس يجب ان يكون 2 او اكثر! ')  
            }  else {
                message.guild.members.forEach( ( member ) => {
                    if(member.voiceChannelID == undefined) return;
                    member.setVoiceChannel(message.guild.members.get(message.author.id).voiceChannelID)
                    });
message.reply('تم سحبهم بنجاح!')
                }
	
};
  
  exports.conf = {
    enabled: true,
    guildOnly: true,
    aliases: ["mv", "mvall"],
    permLevel: "User"
  };
  
  exports.help = {
    name: "moveall",
    category: "Miscelaneous",
    description: "It... like... pings. Then Pongs. And it\"s not Ping Pong.",
    usage: "ping"
  };
  