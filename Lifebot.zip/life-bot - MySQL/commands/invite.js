exports.run = async (client, message, args, level) => { // eslint-disable-line no-unused-vars
  message.channel.send("invite?").then(m => m.edit(`Check your DM`));
  message.author.send("رابط دعوة البوت : \n https://discordapp.com/oauth2/authorize?client_id=326584008425209856&scope=bot&permissions=108526662")
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: "User"
};

exports.help = {
  name: "invite",
  category: "Miscelaneous",
  description: "لدعوه البوت لسيرفرك",
  usage: "invite"
};
