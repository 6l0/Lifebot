exports.run = async (client, message, args, level) => { // eslint-disable-line no-unused-vars
    if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.channel.sendMessage("*:no_entry: ** عذراً ليس لديك صلاحية **");
  if(args[0] == "t") {
    let toMute = message.guild.member(message.mentions.users.first()) || message.guild.members.get(args[0]);
    if(!toMute) return message.channel.send(":exclamation: ** ألرجاء تحديد الشخص عن طريق المنشن **");
    let role = message.guild.roles.find(r => r.name === "Mute");
    if(!role || !toMute.roles.has(role.id)) return message.channel.send(":exclamation: ** ليس لديه ميوت **");
    await toMute.removeRole(role);
    message.channel.send(":white_check_mark:  : **Unmuted**");
    delete mutes[toMute.id];

  } 
  if(args[0] == "v") {
    let toMute = message.guild.member(message.mentions.users.first()) || message.guild.members.get(args[0]);
    if(!toMute) return message.channel.send(":exclamation: ** ألرجاء تحديد الشخص عن طريق المنشن **");
    let role = message.guild.roles.find(r => r.name === "v-Mute");
    if(!role || !toMute.roles.has(role.id)) return message.channel.send(":exclamation: ** ليس لديه ميوت **");
    await toMute.removeRole(role);
    message.channel.send(":white_check_mark:  : **Unmuted**");
    delete mutes[toMute.id];
  }
  fs.writeFile("./data/mutes.json", JSON.stringify(mutes, null, 4), err => {
    if(err) throw err;
  })
};
  
  exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: [],
    permLevel: "User"
  };
  
  exports.help = {
    name: "unmute",
    category: "Miscelaneous",
    description: "It... like... pings. Then Pongs. And it\"s not Ping Pong.",
    usage: "ping"
  };
  