	const Discord = require("discord.js");
  const client = new Discord.Client();

exports.run = (client, message, args, level) => {
 

			 const embed = new Discord.RichEmbed()
          .setColor("RANDOM")
 .setAuthor(` Life Bot - Help Message`)         
.addField(' Tips: ', '** Tips: \n :large_orange_diamond: Premium Only \n :large_blue_diamond: All** \n') 
	.addField('\n :large_blue_diamond: -ping ',`- للاطلاع على سرعة البوت.`)
          .addField(':large_blue_diamond: -bc ',`- لـ ارسال رسالة جماعية لجميع الزوار \n ex : -bc Welcome to server [user]`)
          .addField(':large_blue_diamond: -clear ',`- لحذف محادثات الشات \n ex : -clear 10, -clear @Dr.Faisal 10`)

 //message.channel.send({embed});
 message.author.send(`
 ** Life Bot - Help Message** 
 الأوامر العامة :
 :large_blue_diamond: **-id** : معلومات الشخص 
 :large_blue_diamond: **-ping** : لمعرفة سرعة الاتصال 
 :large_blue_diamond: **-help** : اوامر المساعدة 
 :large_blue_diamond: **-support** : سيرفر الدعم الفني 
 :large_blue_diamond: **-invite** : رابط دعوه البوت 
 ** أوامر ادارة السيرفرات ** 
 :large_blue_diamond: **-mute** : لحجب شخص من التحدث بالشات 
 :large_blue_diamond: **-clear** : لمسح المحادثات بالشات
 **ملاحظة : بامكانك حذف اكثر من 100 ** 
 مثال -clear @Dr.Faisal 100 - سيقوم بحذف 100 رسالة من رسائل فيصل 
 -clear @Admin 100 - سيقوم بحذف 100 رسالة من رول ادمن بهذا الشات  
 :large_blue_diamond: **-welcome** : لـ انشاء ترحيب عند دخول اي شخص لللسيرفر/ديسكورد
 مثال -welcome #welcome اهلا بكـ الى سيرفر [server], [member]
 سيتم استبدال كلاً من:
 **[server]**: الى اسم السيرفر
 **[member]**: الى اسم العضو
 :large_blue_diamond: **-vc** : لانشاء عداد يحسب عدد اعضاء الاشخاص في الفويس
 مثال -vc on فويس [00]
 سيتم استبدال كلاً من:
 **00**: الى عدد اعضاء الاشخاص في الفويس رقماً
 
 يمكن اطفاء كلاً من امر:
 **-vc**,**-welcome**
 بكتابة off
 مثال -vc off, -welcome off
 `)
 
 
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["h", "halp"],
  permLevel: "User"
};

exports.help = {
  name: "help",
  category: "System",
  description: "Displays all the available commands for your permission level.",
  usage: "help [command]"
};
