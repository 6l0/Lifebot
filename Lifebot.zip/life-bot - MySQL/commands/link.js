
exports.run = async (client, message, args) => { 

if(message.member.hasPermission("MANAGE_GUILD")) {
  const args = message.content.split(/\s+/g);

  if(args[1] == "time") {
    if(!args[2]) return;
  var num = parseInt(args[2])
  if(!num) return message.reply('none');
sql.query(`UPDATE guilds SET linktime = ${num} WHERE id = ${message.guild.id}`)
  message.reply('تم التسجيل بنجاح!').then(m => m.delete())
}
if(args[1] == "use") {
  if(!args[2]) return;
var num = parseInt(args[2]);
if(!num) return message.reply('not know!');
sql.query(`UPDATE guilds SET linkage = ${num} WHERE id = ${message.guild.id}`)
message.reply('تم التسجيل بنجاح!').then(m => m.delete())
}
if(args[1] == "تفعيل") {
  if(sql.query(`SELECT linkage FROM guilds WHERE id = ${message.guild.id}`)[0].linkage == 0) return message.reply('يجب تسجيل العدد!');
if(sql.query(`SELECT linktime FROM guilds WHERE id = ${message.guild.id}`)[0].linktime == 0) return message.reply('يجب تسجيل الوقت!');
  if(args[2]) return;
if(sql.query(`SELECT linkactive FROM guilds WHERE id = ${message.guild.id}`)[0].linkactive == 0) {
sql.query(`UPDATE guilds SET linkactive = 1 WHERE id = ${message.guild.id}`)
message.reply('تم تفعيلها بنجاح!!')
} else {
  sql.query(`UPDATE guilds SET linkactive = 0 WHERE id = ${message.guild.id}`)
message.reply('تم اقفال الخاصية بنجاح!')
  }
}
}
}

exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: [],
  permLevel: "User"
};

exports.help = {
  name: "link",
  category: "Miscelaneous",
  description: "It... like... pings. Then Pongs. And it\"s not Ping Pong.",
  usage: "ping"
};
