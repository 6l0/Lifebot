exports.run = async (client, message, args, level) => { 
    if(!message.member.hasPermission('ADMINISTRATOR')) return;
    if(!adblock['code']) {
        adblock['code'] = []
        adblock['one'] = 0;
        adblock['two'] = 0;
        adblock['guilds'] = [];
        adblock["channels"] = {}
    }
    fs.writeFileSync('./data/adblock.json',JSON.stringify(adblock));

    if(adblock['guilds'].includes(message.guild.id)) {
        message.reply(':white_check_mark: ** تم التفعيل مسبقأ **')
    } else {
    if( message.guild.me.hasPermission( 'CREATE_INSTANT_INVITE' ) ) {
        var channels = message.mentions.channels.first();
        if(!channels) return message.reply('يرجى عمل منشن للروم الي نحط فيه الناشرين!')
        channels.createInvite({"maxAge": 0, "maxUses": 0}).then(x => {
        adblock['code'].push(x.code)
        adblock['one']++;
        adblock['guilds'].push(message.guild.id);
        adblock['channels'][message.guild.id] = channels.id;
        fs.writeFileSync('./data/adblock.json',JSON.stringify(adblock));
    });

    } else {
message.reply(' :x: ** عذرأ, ليس لدي صلاحية اخذ روابط بهذا السيرفر **')    }
    }
    console.log(adblock)

}

exports.conf = {
    enabled: true,
    guildOnly: true,
    aliases: ["autodmblock"],
    permLevel: "User"
  };
  
  exports.help = {
    name: "adblock",
    category: "System",
    description: "Displays all the available commands for your permission level.",
    usage: "help [command]"
  };
  