
exports.run = (client, message, args) => {
  if(!message.member.hasPermission("ADMINISTRATOR")) return message.channel.sendMessage("*:no_entry: ** عذراً ليس لديك صلاحية **");

 if(!args[0]) {
let role = message.guild.roles.find(r => r.name === "Mute");
if(!role) return message.reply(' لايوجد اي ميوت! ')

role.members.forEach(u => {
var user = message.guild.members.get(u.id).removeRole(role)
delete mutes[u.id];
fs.writeFile("./data/mutes.json", JSON.stringify(mutes, null, 4), err => {
  if(err) throw err;
})
})
message.reply('تم ذلك!')
}
if(args[0] == "v") {
    let role = message.guild.roles.find(r => r.name === "v-Mute");
if(!role) return message.reply(' لايوجد اي ميوت! ')

role.members.forEach(u => {
var user = message.guild.members.get(u.id).removeRole(role)
delete mutes[u.id];
fs.writeFile("./data/mutes.json", JSON.stringify(mutes, null, 4), err => {
  if(err) throw err;
})
})
message.reply('تم ذلك!')
}
}

exports.conf = {
    enabled: true,
    guildOnly: true,
    aliases: ["uall", "mall", "unmall"],
    permLevel: "User"
  };
  
  exports.help = {
    name: "unmuteall",
    category: "Miscelaneous",
    description: "It... like... pings. Then Pongs. And it\"s not Ping Pong.",
    usage: "ping"
  };