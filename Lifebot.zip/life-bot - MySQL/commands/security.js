exports.run = async (client, message, args, level) => { 
if(!args[0]) return message.reply(' يجب تحديد [ ban [غير مفعله :  kick, channels, roles] ');

if(args[0] == "ban") {
    if(!args[1]) return message.reply(' يجب تحديد العدد! ')
    if(!parseInt(args[1])) return message.reply(' يجب ان تكون ارقام :1234: اولأ): ');
sql.query(`UPDATE guilds SET securitybans = ${args[1]} WHERE id = ${message.guild.id}`)
    message.reply('تم!')
}
}

exports.conf = {
    enabled: true,
    guildOnly: true,
    aliases: [],
    permLevel: "User"
};
  
  exports.help = {
    name: "security",
    category: "System",
    description: "Shuts down the bot. If running under PM2, bot will restart automatically.",
    usage: "reboot"
  };
  