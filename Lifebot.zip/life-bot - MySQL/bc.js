var discord = require('discord.js')
var client = new discord.Client()
const Canvas = require('canvas');
const fs = require('fs');
const jimp = require('jimp');


	client.on("ready", () => {
console.log('ready')
})

client.on('message', message => {
	if(message.content.startsWith('-p')) {
		    message.channel.send("**Generating...**").then(gen => {
 let Image = Canvas.Image,
            canvas = new Canvas(2000, 2000),
            ctx = canvas.getContext('2d');
        ctx.patternQuality = 'bilinear';
        ctx.filter = 'bilinear';
        ctx.antialias = 'subpixel';
        ctx.shadowColor = 'rgba(0, 0, 0, 0.4)';
        ctx.shadowOffsetY = 2;
        ctx.shadowBlur = 2;
        fs.readFile("https://github.com/funnbot/Nitro/blob/master/images/bg/nightsky/3.png", function (err, Background) {
            if (err) return console.log(err);
            let BG = Canvas.Image;
            let ground = new Image;
            ground.src = Background;
            ctx.drawImage(ground, 0, 0, 2000, 2000);
            fs.readFile('https://github.com/funnbot/Nitro/blob/master/images/profile.png', (err, profile) => {
                if (err) return console.log(err);
                let that = new Image;
                that.src = profile;
                ctx.drawImage(that, 0, 0, 2000, 2000)
                let url = user.displayAvatarURL.endsWith(".webp") ? user.displayAvatarURL.slice(0, -5) + ".png" : user.displayAvatarURL;
                jimp.read(url, (err, ava) => {
                    if (err) return console.log(err);
                    ava.getBuffer(jimp.MIME_PNG, (err, buf) => {
                        if (err) return console.log(err);

                        //Avatar
                        let Avatar = Canvas.Image;
                        let ava = new Avatar;
                        ava.src = buf;
                        ctx.drawImage(ava, 117, 122, 550, 550);

                        //Level
                        ctx.font = "bold 286px Helvetica";
                        ctx.fillStyle = "#FFFFFF";
                        ctx.textAlign = "center";
                        ctx.fillText("5", 1625, 520);

                        //Name
                        ctx.font = "bold 175px Helvetica";
                        ctx.fillStyle = "#FFFFFF";
                        ctx.textAlign = "left";
                        ctx.fillText(message.author.username, 55, 985);

                        //Sent

                            sent = 0;
             
                        ctx.font = "bold 120px Helvetica";
                        ctx.textAlign = "center";
                        ctx.fillText(sent, 311, 1415);

                        //Global Rank
                        ctx.font = "bold 100px Helvetica";
                        console.log("Rank: " + '55')
 
                            rank = 0;
                        ctx.fillText(rank, 1756, 1390);

                        //Money
                        ctx.font = "bold 130px Helvetica";
                        ctx.textAlign = "right";
                        ctx.fillText("5000 $", 1928, 1176);

                        let canvas2 = new Canvas(400, 400)
                        let ctx2 = canvas2.getContext('2d')

                        ctx2.drawImage(canvas, 0, 0, 400, 400)

                        canvas2.toBuffer((err, buf) => {
                            if (err) return console.log(err);
                            message.channel.sendFile(buf);
                            gen.edit("**Here is " + user.username + "'s Profile**");
                        })
                    })
                })
            })
        })
    })
}
})
client.login('NTA1Njk1MjA5ODkyNjEwMDQ4.DrXWGg.QlFiecAG-CSB8ak5fxYRwzI1oTo')
